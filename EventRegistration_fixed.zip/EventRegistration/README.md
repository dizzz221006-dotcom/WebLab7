# Event Registration API

Spring Boot REST API for managing events. Data is stored in memory and resets when the application restarts.

## Run

Use JDK 17 or the JDK configured for this project.

- Windows: `gradlew.bat bootRun`
- macOS/Linux: `./gradlew bootRun`

Base URL: `http://localhost:8080`

## Endpoints

| Method | Endpoint | Behavior |
|---|---|---|
| GET | `/api/events` | Return all events |
| GET | `/api/events?title=quiz` | Case-insensitive title search |
| GET | `/api/events/{id}` | Return one event, or 404 |
| POST | `/api/events` | Create event; returns 201 |
| PUT | `/api/events/{id}` | Replace title and location; preserves ID |
| DELETE | `/api/events/{id}` | Delete event; returns 204, or 404 |

POST and PUT JSON body:

```json
{
  "title": "Web Design Workshop",
  "location": "Room 101"
}
```

Both `title` and `location` must be non-blank; otherwise the API returns 400.
IDs are assigned by the server and are not reused after deletion during the same run.
