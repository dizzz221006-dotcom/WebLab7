package kz.iitu.eventregistration.service;

import kz.iitu.eventregistration.model.EventInfo;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EventService {

    private final List<EventInfo> events = new ArrayList<>(List.of(
            new EventInfo(1, "Web Design Workshop", "Room 101"),
            new EventInfo(2, "JavaScript Quiz", "Online"),
            new EventInfo(3, "IT Career Talk", "Room 202")
    ));

    // Keep increasing after deletion so an ID is not reused during this run.
    private int nextId = 4;

    public String getWelcomeMessage() {
        return "Welcome to the Event Registration API";
    }

    public List<EventInfo> getAllEvents() {
        return new ArrayList<>(events);
    }

    public List<EventInfo> searchEventsByTitle(String title) {
        if (title == null || title.isBlank()) {
            return getAllEvents();
        }
        String query = title.trim().toLowerCase();
        return events.stream()
                .filter(event -> event.title().toLowerCase().contains(query))
                .toList();
    }

    public Optional<EventInfo> getEventById(int id) {
        return events.stream()
                .filter(event -> event.id() == id)
                .findFirst();
    }

    public EventInfo createEvent(String title, String location) {
        EventInfo event = new EventInfo(nextId++, title.trim(), location.trim());
        events.add(event);
        return event;
    }

    public Optional<EventInfo> updateEvent(int id, String title, String location) {
        for (int i = 0; i < events.size(); i++) {
            if (events.get(i).id() == id) {
                EventInfo updated = new EventInfo(id, title.trim(), location.trim());
                events.set(i, updated);
                return Optional.of(updated);
            }
        }
        return Optional.empty();
    }

    public boolean deleteEvent(int id) {
        return events.removeIf(event -> event.id() == id);
    }
}
