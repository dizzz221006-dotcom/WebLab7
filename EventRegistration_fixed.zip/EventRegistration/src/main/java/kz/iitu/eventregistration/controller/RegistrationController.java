package kz.iitu.eventregistration.controller;

import kz.iitu.eventregistration.model.EventInfo;
import kz.iitu.eventregistration.service.EventService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class RegistrationController {

    private final EventService eventService;

    @Value("${spring.application.name}")
    private String applicationName;

    @Value("${app.course}")
    private String course;

    @Value("${app.semester}")
    private int semester;

    // Constructor injection keeps the service managed by Spring.
    public RegistrationController(EventService eventService) {
        this.eventService = eventService;
    }

    @GetMapping("/hello")
    public Map<String, String> hello() {
        return Map.of("message", eventService.getWelcomeMessage());
    }

    @GetMapping("/info")
    public Map<String, Object> getInfo() {
        return Map.of(
                "applicationName", applicationName,
                "course", course,
                "semester", semester
        );
    }

    @GetMapping("/events")
    public List<EventInfo> getEvents(
            @RequestParam(required = false) String title) {
        if (title == null) {
            return eventService.getAllEvents();
        }
        return eventService.searchEventsByTitle(title);
    }

    @GetMapping("/events/{id}")
    public ResponseEntity<EventInfo> getEventById(@PathVariable int id) {
        return eventService.getEventById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/events")
    public ResponseEntity<?> createEvent(@RequestBody EventInfo request) {
        if (!isValid(request)) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "title and location must not be blank"));
        }

        // Ignore any ID supplied by the client; the server assigns it.
        EventInfo created = eventService.createEvent(request.title(), request.location());
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/events/{id}")
    public ResponseEntity<?> updateEvent(
            @PathVariable int id,
            @RequestBody EventInfo request) {
        if (!isValid(request)) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "title and location must not be blank"));
        }

        return eventService.updateEvent(id, request.title(), request.location())
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @DeleteMapping("/events/{id}")
    public ResponseEntity<Void> deleteEvent(@PathVariable int id) {
        if (!eventService.deleteEvent(id)) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }

    private boolean isValid(EventInfo event) {
        return event != null
                && event.title() != null && !event.title().isBlank()
                && event.location() != null && !event.location().isBlank();
    }
}
